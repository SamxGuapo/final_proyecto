﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace trabajoooao
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void Form7_Load(object sender, EventArgs e)
        {

        }

        private void cancelar_Click(object sender, EventArgs e)
        {
            bienvenida form6 = new bienvenida();
            form6.Show();
            this.Hide();
        }

        private void textGuardar_Click(object sender, EventArgs e)
        {
            SqlConnection conexion = CONEXION_SQL.conectarSQL();
            {
                String guery = "INSERT INTO Dinero (Cedula , Nombres , Apellidos , Valorcancelar, Totalpagar )VALUES( @Cedula , @Nombres , @Apellidos , @Valorcancelar , @Totalpagar)";
                SqlCommand cmd = new SqlCommand(guery, conexion);
                cmd.Parameters.AddWithValue("@Cedula", TXTCEDULA.Text);
                cmd.Parameters.AddWithValue("@Nombres", TXTNOMBRES.Text);
                cmd.Parameters.AddWithValue("@Apellidos", TXTAPELLIDOS.Text);
                cmd.Parameters.AddWithValue("@Valorcancelar", TXTVALOR.Text);
                cmd.Parameters.AddWithValue("@Totalpagar", TXTTOTAL.Text);



                if (cmd.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("Datos guardados exitosamente", "Informacion", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
               
            }
        }

        private void TXTTOTAL_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void TXTCEDULA_KeyPress(object sender, KeyPressEventArgs e)
        {
            Validar.numero(e);
        }

        private void TXTAPELLIDOS_KeyPress(object sender, KeyPressEventArgs e)
        {
            Validar.letra(e);
        }

        private void TXTCEDULA_TextChanged(object sender, EventArgs e)
        {
            string guery = "SELECT Cedula, Nombres, Apellidos From Datos WHERE Cedula=@Cedula";

            SqlConnection conexion = CONEXION_SQL.conectarSQL();
            SqlCommand cmd = new SqlCommand(guery, conexion);
            cmd.Parameters.AddWithValue("@Cedula", TXTCEDULA.Text);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                TXTCEDULA.Text = reader["Cedula"].ToString();
                TXTNOMBRES.Text = reader["Nombres"].ToString();
                TXTAPELLIDOS.Text = reader["Apellidos"].ToString();

            }
        }
    }
}
