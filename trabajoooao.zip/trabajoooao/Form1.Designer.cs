﻿namespace trabajoooao
{
    partial class bienvenida
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtnuevo_prestamo = new System.Windows.Forms.Button();
            this.txtbuscar_cliente = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // txtnuevo_prestamo
            // 
            this.txtnuevo_prestamo.BackColor = System.Drawing.Color.Transparent;
            this.txtnuevo_prestamo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.txtnuevo_prestamo.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnuevo_prestamo.Image = global::trabajoooao.Properties.Resources.pito__1;
            this.txtnuevo_prestamo.Location = new System.Drawing.Point(61, 266);
            this.txtnuevo_prestamo.Name = "txtnuevo_prestamo";
            this.txtnuevo_prestamo.Size = new System.Drawing.Size(140, 49);
            this.txtnuevo_prestamo.TabIndex = 1;
            this.txtnuevo_prestamo.Text = "NUEVO PRESTAMO";
            this.txtnuevo_prestamo.UseVisualStyleBackColor = false;
            this.txtnuevo_prestamo.LocationChanged += new System.EventHandler(this.label1_Click);
            this.txtnuevo_prestamo.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtbuscar_cliente
            // 
            this.txtbuscar_cliente.BackColor = System.Drawing.Color.Transparent;
            this.txtbuscar_cliente.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.txtbuscar_cliente.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbuscar_cliente.Image = global::trabajoooao.Properties.Resources.pito__1;
            this.txtbuscar_cliente.Location = new System.Drawing.Point(729, 263);
            this.txtbuscar_cliente.Name = "txtbuscar_cliente";
            this.txtbuscar_cliente.Size = new System.Drawing.Size(145, 49);
            this.txtbuscar_cliente.TabIndex = 3;
            this.txtbuscar_cliente.Text = "BUSCAR CLIENTE ";
            this.txtbuscar_cliente.UseVisualStyleBackColor = false;
            this.txtbuscar_cliente.Click += new System.EventHandler(this.buscar_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = global::trabajoooao.Properties.Resources.Imagen_de_WhatsApp_2024_05_12_a_las_10_56_19_f5bcf77b_removebg_preview;
            this.pictureBox3.Location = new System.Drawing.Point(729, 151);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(145, 109);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 5;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = global::trabajoooao.Properties.Resources.Imagen_de_WhatsApp_2024_05_12_a_las_10_27_40_7e09740f_removebg_preview;
            this.pictureBox2.Location = new System.Drawing.Point(61, 151);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(140, 109);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.label1_Click);
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.BackColor = System.Drawing.Color.Transparent;
            this.label.Cursor = System.Windows.Forms.Cursors.No;
            this.label.Font = new System.Drawing.Font("Arial", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label.Image = global::trabajoooao.Properties.Resources.pito__1;
            this.label.Location = new System.Drawing.Point(253, 25);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(427, 44);
            this.label.TabIndex = 6;
            this.label.Text = "¿QUE DESEA HACER?";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::trabajoooao.Properties.Resources.Imagen_de_WhatsApp_2024_05_12_a_las_08_51_25_bca1bf01_removebg_preview;
            this.pictureBox1.Location = new System.Drawing.Point(294, 105);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(332, 191);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Image = global::trabajoooao.Properties.Resources.pito__1;
            this.button1.Location = new System.Drawing.Point(12, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(156, 34);
            this.button1.TabIndex = 8;
            this.button1.Text = "VOLVER AL INICIO";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Image = global::trabajoooao.Properties.Resources.pito__1;
            this.button3.Location = new System.Drawing.Point(388, 428);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(145, 49);
            this.button3.TabIndex = 10;
            this.button3.Text = "REGISTRO DE PAGOS";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.Image = global::trabajoooao.Properties.Resources.REGISTRO_removebg_preview;
            this.pictureBox4.Location = new System.Drawing.Point(388, 302);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(145, 109);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 11;
            this.pictureBox4.TabStop = false;
            // 
            // bienvenida
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.BackgroundImage = global::trabajoooao.Properties.Resources.pito__;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(931, 520);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.txtbuscar_cliente);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txtnuevo_prestamo);
            this.Name = "bienvenida";
            this.Text = "CREDITOS APP";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button txtnuevo_prestamo;
        private System.Windows.Forms.Button txtbuscar_cliente;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.PictureBox pictureBox4;
    }
}

