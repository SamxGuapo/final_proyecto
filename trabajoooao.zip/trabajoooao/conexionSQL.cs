﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace trabajoooao

{
    public static class CONEXION_SQL
    {
        public static SqlConnection conectarSQL()
        {
            string connectionString = "Data source=DESKTOP-G7GPUHH\\SQLEXPRESS; Initial Catalog=BD_PROYECTO; Integrated Security=True";
            SqlConnection connection = new SqlConnection(connectionString);

            connection.Open();


            return connection;
        }
    }
}
